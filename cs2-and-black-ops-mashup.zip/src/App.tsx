import { Shield, Crosshair, Waves, Swords } from "lucide-react";
import { useState } from "react";

const weapons = [
  { name: "AK-47 Loadout", ref: "AK-47", mode: "Tactical Assault", damage: 120, clip: 30, playable: true },
  { name: "M4A4 Loadout", ref: "M4A4", mode: "Precision Marksman", damage: 100, clip: 30, playable: true },
  { name: "AWP Loadout", ref: "AWP", mode: "Heavy Sniper", damage: 300, clip: 5, playable: false },
];

const loadouts = [
  { name: "Tactical Assault", weapon: "AK-47 Loadout", perks: "Juggernog + Speed Cola", cost: 2000, wave: 1, active: true },
  { name: "Precision Marksman", weapon: "M4A4 Loadout", perks: "Quick Revive + Double Tap", cost: 2500, wave: 5, active: true },
  { name: "Heavy Sniper", weapon: "AWP Loadout", perks: "Stamin-Up + Mule Kick", cost: 3500, wave: 10, active: false },
];

export default function App() {
  const [selected, setSelected] = useState("Tactical Assault");

  const activeLoadout = loadouts.find((l) => l.name === selected);
  const weapon = weapons.find((w) => w.name === activeLoadout?.weapon);

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-950 via-orange-950 to-black text-amber-50">
      <header className="border-b border-amber-900/50 bg-black/40 backdrop-blur-md">
        <div className="mx-auto max-w-5xl px-6 py-10">
          <div className="flex items-center gap-3 mb-4">
            <span className="inline-flex h-2 w-2 rounded-full bg-green-400 animate-pulse" />
            <span className="text-xs font-mono tracking-widest uppercase text-amber-500">Mashup — Build in Progress</span>
          </div>
          <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-orange-200 to-amber-500 mb-3">
            Black Ops II Zombies × CS2 Loadouts
          </h1>
          <p className="text-amber-200/70 text-lg max-w-2xl leading-relaxed">
            A Black Ops II Zombies co-op mod (2–4 players) that pulls Counter-Strike 2 weapon audio and loadouts from your installed CS2 folder. Runs via T6SP-Mod / GSC loader — no VAC interaction.
          </p>
          <div className="mt-6 flex flex-wrap gap-3 text-xs font-mono text-amber-400/60">
            <span className="px-2 py-1 rounded-full bg-amber-900/30 border border-amber-800/30">Host: BO2 (IW Engine)</span>
            <span className="px-2 py-1 rounded-full bg-amber-900/30 border border-amber-800/30">Assets: CS2 (read-only)</span>
            <span className="px-2 py-1 rounded-full bg-amber-900/30 border border-amber-800/30">Multiplayer: 2–4 co-op</span>
            <span className="px-2 py-1 rounded-full bg-amber-900/30 border border-amber-800/30">Loader: T6SP-Mod / GSC</span>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-5xl px-6 py-12 space-y-16">
        {/* System status / preflight summary */}
        <section className="rounded-2xl border border-amber-800/20 bg-amber-950/30 p-6 md:p-8 shadow-2xl shadow-amber-950/20">
          <h2 className="text-xl font-bold text-amber-100 mb-4 flex items-center gap-2">
            <Shield className="w-5 h-5 text-amber-400" /> System Status
          </h2>
          <div className="grid md:grid-cols-3 gap-4 text-sm">
            <div className="rounded-xl bg-black/20 p-4 border border-amber-900/20">
              <h3 className="font-semibold text-amber-200 mb-1">Preflight</h3>
              <p className="text-amber-300/80">Clean (provisional). Cross-references verified in sheets.</p>
            </div>
            <div className="rounded-xl bg-black/20 p-4 border border-amber-900/20">
              <h3 className="font-semibold text-amber-200 mb-1">Anti-Cheat</h3>
              <p className="text-amber-300/80">Safe: no load into CS2. Only reads installed folder for assets.</p>
            </div>
            <div className="rounded-xl bg-black/20 p-4 border border-amber-900/20">
              <h3 className="font-semibold text-amber-200 mb-1">First Version</h3>
              <p className="text-amber-300/80">One Zombies map + 2 active loadouts. AWP excluded.</p>
            </div>
          </div>
        </section>

        {/* Loadout selector */}
        <section>
          <h2 className="text-2xl font-extrabold text-amber-100 mb-6 flex items-center gap-3">
            <Crosshair className="w-6 h-6 text-orange-400" /> Loadouts
          </h2>
          <div className="grid md:grid-cols-3 gap-4 mb-8">
            {loadouts.map((l) => (
              <button
                key={l.name}
                onClick={() => setSelected(l.name)}
                className={`text-left rounded-2xl border p-6 transition-all duration-300 shadow-lg ${
                  selected === l.name
                    ? "bg-gradient-to-br from-orange-900/60 to-amber-900/40 border-orange-400/50 scale-[1.02] shadow-orange-900/30"
                    : "bg-amber-950/20 border-amber-800/20 hover:border-amber-600/30 hover:bg-amber-950/30"
                }`}
              >
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-bold text-lg text-amber-50">{l.name}</h3>
                  {!l.active && (
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-amber-900/40 text-amber-400 border border-amber-700/30">Coming Soon</span>
                  )}
                </div>
                <p className="text-sm text-amber-300/70 mb-1">Weapon: <span className="text-amber-200 font-medium">{l.weapon}</span></p>
                <p className="text-sm text-amber-300/70 mb-3">Perks: <span className="text-amber-200">{l.perks}</span></p>
                <div className="flex items-center gap-3 text-xs font-mono text-amber-500/70">
                  <span>Cost: {l.cost}</span>
                  <span>·</span>
                  <span>Wave: {l.wave}</span>
                </div>
              </button>
            ))}
          </div>

          {/* Active selection detail */}
          {activeLoadout && weapon && (
            <div className="rounded-2xl border border-orange-900/30 bg-gradient-to-r from-amber-950/50 to-orange-950/30 p-6 md:p-8 shadow-inner shadow-amber-950/10">
              <div className="flex flex-col md:flex-row md:items-start gap-6">
                <div className="flex-1">
                  <h3 className="text-2xl font-extrabold text-amber-100 mb-2">{activeLoadout.name}</h3>
                  <p className="text-amber-200/70 mb-4">Selected loadout for BO2 Zombies co-op.</p>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    <div className="rounded-xl bg-black/20 border border-amber-900/20 p-3">
                      <span className="text-[10px] uppercase tracking-wider text-amber-500 font-mono">Weapon</span>
                      <p className="font-bold text-amber-100">{weapon.ref}</p>
                    </div>
                    <div className="rounded-xl bg-black/20 border border-amber-900/20 p-3">
                      <span className="text-[10px] uppercase tracking-wider text-amber-500 font-mono">Damage</span>
                      <p className="font-bold text-amber-100">{weapon.damage}</p>
                    </div>
                    <div className="rounded-xl bg-black/20 border border-amber-900/20 p-3">
                      <span className="text-[10px] uppercase tracking-wider text-amber-500 font-mono">Clip</span>
                      <p className="font-bold text-amber-100">{weapon.clip}</p>
                    </div>
                    <div className="rounded-xl bg-black/20 border border-amber-900/20 p-3">
                      <span className="text-[10px] uppercase tracking-wider text-amber-500 font-mono">Playable</span>
                      <p className={`font-bold ${weapon.playable ? "text-green-400" : "text-red-400"}`}>
                        {weapon.playable ? "Yes" : "No (v1)"}
                      </p>
                    </div>
                  </div>
                </div>
                <div className="md:w-72 rounded-xl bg-black/20 border border-amber-900/20 p-5">
                  <h4 className="font-bold text-amber-100 mb-3">Perk Equivalents</h4>
                  <p className="text-sm text-amber-200/70">{activeLoadout.perks}</p>
                  <h4 className="font-bold text-amber-100 mt-4 mb-2">Economy</h4>
                  <p className="text-sm text-amber-200/70">{activeLoadout.cost} points · Unlock at wave {activeLoadout.wave}</p>
                </div>
              </div>
            </div>
          )}
        </section>

        {/* Weapons table */}
        <section>
          <h2 className="text-2xl font-extrabold text-amber-100 mb-6 flex items-center gap-3">
            <Waves className="w-6 h-6 text-amber-400" /> Weapons
          </h2>
          <div className="overflow-x-auto rounded-2xl border border-amber-800/20 shadow-xl">
            <table className="w-full text-sm">
              <thead className="bg-amber-950/60 text-amber-300 font-mono uppercase text-xs tracking-wider">
                <tr>
                  <th className="text-left px-4 py-3">Name</th>
                  <th className="text-left px-4 py-3">CS2 Ref</th>
                  <th className="text-right px-4 py-3">Damage</th>
                  <th className="text-right px-4 py-3">Clip</th>
                  <th className="text-right px-4 py-3">Reload</th>
                  <th className="text-center px-4 py-3">First Version</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-amber-900/20 bg-amber-950/10">
                {weapons.map((w) => (
                  <tr key={w.name} className="hover:bg-amber-950/20 transition-colors">
                    <td className="px-4 py-3 font-medium text-amber-100">{w.name}</td>
                    <td className="px-4 py-3 text-amber-300/80">{w.ref}</td>
                    <td className="px-4 py-3 text-right font-mono text-amber-200">{w.damage}</td>
                    <td className="px-4 py-3 text-right font-mono text-amber-200">{w.clip}</td>
                    <td className="px-4 py-3 text-right font-mono text-amber-200">—</td>
                    <td className="px-4 py-3 text-center">
                      <span className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-mono border ${w.playable ? "bg-green-900/30 text-green-400 border-green-800/30" : "bg-red-900/30 text-red-400 border-red-800/30"}`}>
                        {w.playable ? "Active" : "Excluded"}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        {/* Required games */}
        <section className="rounded-2xl border border-green-900/20 bg-gradient-to-br from-green-950/20 to-emerald-950/10 p-6 md:p-8 shadow-xl shadow-green-950/10">
          <h2 className="text-xl font-bold text-green-100 mb-4 flex items-center gap-2">
            <Swords className="w-5 h-5 text-green-400" /> Required Games
          </h2>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="rounded-xl bg-black/20 p-5 border border-green-900/20">
              <h3 className="font-bold text-green-200 mb-1">Call of Duty: Black Ops II</h3>
              <p className="text-sm text-green-300/70 mb-2">Host game. Required to launch.</p>
              <p className="text-xs text-green-400/60 font-mono">Engine: IW Engine · Loader: T6SP-Mod / GSC</p>
            </div>
            <div className="rounded-xl bg-black/20 p-5 border border-amber-900/20">
              <h3 className="font-bold text-amber-200 mb-1">Counter-Strike 2</h3>
              <p className="text-sm text-amber-300/70 mb-2">Asset source only. Read-only folder access.</p>
              <p className="text-xs text-amber-400/60 font-mono">Engine: Source 2 · No load-in · No VAC risk</p>
            </div>
          </div>
        </section>
      </main>

      <footer className="mx-auto max-w-5xl px-6 py-8 text-xs text-amber-500/40 font-mono border-t border-amber-900/10">
        <p>Provisional build — assumption: BO2 Zombies co-op (2-4 players) with CS2 assets. Confirmed by user? Not yet explicitly. Sheets clean.</p>
        <p className="mt-1">Preflight: clean. Universal-modder: not cloned (needs bash). Folder paths: not provided yet.</p>
      </footer>
    </div>
  );
}
